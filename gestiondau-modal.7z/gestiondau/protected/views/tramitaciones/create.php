<?php
/* @var $this TramitacionesController */
/* @var $model Tramitaciones */
?>

<h1>Asignar Expediente</h1>

<?php $this->renderPartial('_form', array('model'=>$model)); ?>