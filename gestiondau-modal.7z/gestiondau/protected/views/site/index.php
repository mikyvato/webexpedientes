
<?php /* @var $this SiteController */ 
$this->pageTitle=Yii::app()->name; ?>

<img src="<?php echo Yii::app()->theme->baseUrl; ?>/img/fondboot.png"  
     style="position:absolute;max-height:82%;height:auto;width:100%;max-width:100%;margin:auto;display: block;">
